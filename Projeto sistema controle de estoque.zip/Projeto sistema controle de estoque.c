
#include <stdio.h>

int main() {

  char nomeProduto[50];

  int codigoProduto;

  int quantidadeEstoque;



  printf("CADASTRO DE PRODUTO\n");

   

  printf("Digite o nome do produto: ");

  scanf("%49[^\n]", nomeProduto); 



  printf("Digite o código do produto: ");

  scanf("%d", &codigoProduto);



  printf("Digite a quantidade inicial em estoque: ");

  scanf("%d", &quantidadeEstoque);



  printf("\n--------------------------------------------\n");

  printf("DADOS DO PRODUTO CADASTRADO:\n");

  printf("Nome: %s\n", nomeProduto);

  printf("Código: %d\n", codigoProduto);

  printf("Quantidade em Estoque: %d\n", quantidadeEstoque);

  printf("--------------------------------------------\n");



  return 0;

}



int main() {

  char nomeProduto[50];

  int codigoProduto;

  int quantidadeEstoque;

  const int ESTOQUE_MINIMO = 10; 



  printf("VERIFICAÇÃO DE ESTOQUE\n");

  printf("Digite o nome do produto: ");

  scanf("%49s", nomeProduto); 



  printf("Digite a quantidade em estoque: ");

  scanf("%d", &quantidadeEstoque);



  printf("\n--- STATUS DO PRODUTO ---\n");

  printf("Produto: %s\n", nomeProduto);

  printf("Estoque Atual: %d\n", quantidadeEstoque);



  if (quantidadeEstoque < ESTOQUE_MINIMO) {

    printf(" ALERTA DE REPOSIÇÃO! O estoque está abaixo do mínimo (%d).\n", ESTOQUE_MINIMO);

  } else {

    // Bloco executado se a condição for falsa

    printf("stoque em nível seguro.\n");

  }



  printf("-----------------------------------------\n");



  return 0;

}



int main() {

  int quantidadeEstoque = 100; 

  int opcao = 0;

  int quantidadeMovimentada;



  printf("MOVIMENTAÇÃO DE ESTOQUE \n");

  printf("Estoque inicial (Produto Exemplo): %d\n\n", quantidadeEstoque);



  

  while (opcao != 3) {

    printf("\n--- MENU DE OPERAÇÕES ---\n");

    printf("Estoque Atual: %d\n", quantidadeEstoque);

    printf("1. Entrada de Produtos\n");

    printf("2. Saída de Produtos\n");

    printf("3. Sair\n");

    printf("Escolha uma opção: ");

    scanf("%d", &opcao);



    switch (opcao) {

      case 1: 

        printf("Digite a quantidade a ser adicionada: ");

        scanf("%d", &quantidadeMovimentada);

        if (quantidadeMovimentada > 0) {

          quantidadeEstoque += quantidadeMovimentada;

          printf("entrada registrada. Novo estoque: %d\n", quantidadeEstoque);

        } else {

          printf(" Quantidade inválida.\n");

        }

        break;



      case 2: 

        printf("Digite a quantidade a ser retirada: ");

        scanf("%d", &quantidadeMovimentada);

        if (quantidadeMovimentada > 0 && quantidadeMovimentada <= quantidadeEstoque) {

          quantidadeEstoque -= quantidadeMovimentada;

          printf("Saída registrada. Novo estoque: %d\n", quantidadeEstoque);

        } else if (quantidadeMovimentada > quantidadeEstoque) {

          printf(" Erro: Quantidade a ser retirada é maior que o estoque atual.\n");

        } else {

          printf("Quantidade inválida.\n");

        }

        break;



      case 3: // Sair

        printf("Encerrando o sistema de movimentação.\n");

        break;



      default:

        printf("pção inválida. Tente novamente.\n");

        

        while (getchar() != '\n');

        break;

    }

  }



  return 0;

}



typedef struct {

  char nome[50];

  int codigo;

  int quantidade;

} Produto;



#define MAX_PRODUTOS 5 



int main() {

  Produto estoque[MAX_PRODUTOS]; 

  int numProdutos = 0; 



  printf("CADASTRO E CONSULTA\n");

   



  if (numProdutos < MAX_PRODUTOS) {

    strcpy(estoque[numProdutos].nome, "Monitor LED 24'");

    estoque[numProdutos].codigo = 101;

    estoque[numProdutos].quantidade = 25;

    numProdutos++;

  }



  

  if (numProdutos < MAX_PRODUTOS) {

    strcpy(estoque[numProdutos].nome, "Teclado Mecânico");

    estoque[numProdutos].codigo = 205;

    estoque[numProdutos].quantidade = 8;

    numProdutos++;

  }



  printf("\n--- LISTA DE PRODUTOS CADASTRADOS (%d/%d) ---\n", numProdutos, MAX_PRODUTOS);



  for (int i = 0; i < numProdutos; i++) {

    printf("ID: %d | Código: %d | Nome: %s | Qtd: %d\n", 

        i + 1, 

        estoque[i].codigo, 

        estoque[i].nome, 

        estoque[i].quantidade);

  }

  printf("----------------------------------------------------\n");



  int codigoBusca = 205;

  int encontrado = 0;



  printf("\n--- CONSULTA DE PRODUTO (Cód: %d) ---\n", codigoBusca);

  for (int i = 0; i < numProdutos; i++) {

    if (estoque[i].codigo == codigoBusca) {

      printf("Produto Encontrado:\n");

      printf("Nome: %s | Qtd: %d\n", estoque[i].nome, estoque[i].quantidade);

      encontrado = 1;

      break; 

    }

  }



  if (!encontrado) {

    printf("Produto com código %d não encontrado.\n", codigoBusca);

  }

  printf("-----------------------------------------\n");



  return 0;

}



typedef struct {

  char nome[50];

  int codigo;

  int quantidade;

} Produto;



#define MAX_PRODUTOS 10 

#define ESTOQUE_MINIMO 10 



Produto estoque[MAX_PRODUTOS]; 

int numProdutos = 0; 



int buscarProdutoPorCodigo(int codigo) {

  for (int i = 0; i < numProdutos; i++) {

    if (estoque[i].codigo == codigo) {

      return i; 

    }

  }

  return -1; 

}



void exibirProduto(int index) {

  if (index >= 0 && index < numProdutos) {

    printf(" | Código: %d | Nome: %s | Qtd: %d", 

        estoque[index].codigo, 

        estoque[index].nome, 

        estoque[index].quantidade);

     

    if (estoque[index].quantidade < ESTOQUE_MINIMO) {

      printf(" (BAIXO ESTOQUE: Mínimo %d)", ESTOQUE_MINIMO);

    }

    printf("\n");

  }

}



void cadastrarProduto() {

  if (numProdutos >= MAX_PRODUTOS) {

    printf(" Estoque cheio! Não é possível cadastrar mais produtos.\n");

    return;

  }



  printf("\n--- CADASTRO DE NOVO PRODUTO ---\n");



  int novoCodigo;

  printf("Digite o código do produto: ");

  scanf("%d", &novoCodigo);



  // Verifica se o código já existe

  if (buscarProdutoPorCodigo(novoCodigo) != -1) {

    printf(" Erro: Código %d já cadastrado.\n", novoCodigo);

    return;

  }



  estoque[numProdutos].codigo = novoCodigo;



  while (getchar() != '\n'); 



  printf("Digite o nome do produto: ");

  scanf("%49[^\n]", estoque[numProdutos].nome); 



  printf("Digite a quantidade inicial: ");

  scanf("%d", &estoque[numProdutos].quantidade);



  numProdutos++;

  printf("Produto cadastrado com sucesso! (%d/%d)\n", numProdutos, MAX_PRODUTOS);

}



void entradaEstoque() {

  int codigo, quantidade;

  printf("\n--- ENTRADA DE PRODUTOS ---\n");

  printf("Digite o código do produto para entrada: ");

  scanf("%d", &codigo);



  int index = buscarProdutoPorCodigo(codigo);



  if (index != -1) {

    printf("Produto encontrado:");

    exibirProduto(index);



    printf("Digite a quantidade a adicionar: ");

    scanf("%d", &quantidade);



    if (quantidade > 0) {

      estoque[index].quantidade += quantidade;

      printf("Entrada de %d unidades registrada. Novo estoque:", quantidade);

      exibirProduto(index);

    } else {

      printf(" Quantidade inválida para entrada.\n");

    }

  } else {

    printf("Produto com código %d não encontrado.\n", codigo);

  }

}



void saidaEstoque() {

  int codigo, quantidade;

  printf("\n--- SAÍDA DE PRODUTOS ---\n");

  printf("Digite o código do produto para saída: ");

  scanf("%d", &codigo);



  int index = buscarProdutoPorCodigo(codigo);



  if (index != -1) {

    printf("Produto encontrado:");

    exibirProduto(index);

     

    printf("Digite a quantidade a retirar: ");

    scanf("%d", &quantidade);



    if (quantidade > 0 && quantidade <= estoque[index].quantidade) {

      estoque[index].quantidade -= quantidade;

      printf("Saída de %d unidades registrada. Novo estoque:", quantidade);

      exibirProduto(index);

    } else if (quantidade > estoque[index].quantidade) {

      printf(" Erro: Quantidade a retirar (%d) é maior que o estoque atual (%d).\n", quantidade, estoque[index].quantidade);

    } else {

      printf(" Quantidade inválida para saída.\n");

    }

  } else {

    printf("produto com código %d não encontrado.\n", codigo);

  }

}





void listarProdutos() {

  if (numProdutos == 0) {

    printf("Nenhum produto cadastrado.\n");

    return;

  }



  for (int i = 0; i < numProdutos; i++) {

    exibirProduto(i);

  }

  printf("------------------------------------------------------\n");

}





int main() {

  int opcao;



  strcpy(estoque[0].nome, "Mouse sem fio"); estoque[0].codigo = 301; estoque[0].quantidade = 5; numProdutos++;

  strcpy(estoque[1].nome, "Cabo HDMI 2m"); estoque[1].codigo = 450; estoque[1].quantidade = 30; numProdutos++;



  do {



    printf("\n SISTEMA DE CONTROLE DE ESTOQUE\n");

    printf("============================================\n");

    printf("1. Cadastrar Novo Produto\n");

    printf("2. Entrada de Estoque\n");

    printf("3. Saída de Estoque\n");

    printf("4. Consultar/Listar Produtos\n");

    printf("5. Sair\n");

    printf("--------------------------------------------\n");

    printf("Escolha uma opção: ");

    scanf("%d", &opcao);



    while (getchar() != '\n');



    switch (opcao) {

      case 1:

        cadastrarProduto();

        break;

      case 2:

        entradaEstoque();

        break;

      case 3:

        saidaEstoque();

        break;

      case 4:

        listarProdutos();

        break;

      case 5:

        printf("\n Sistema encerrado. Até mais!\n");

        break;

      default:

        printf("\n opção inválida. Tente novamente.\n");

        break;

    }

     

    if (opcao != 5) {

       printf("\nPressione ENTER para continuar...");

       getchar(); 

    }



  } while (opcao != 5);



  return 0;

}

